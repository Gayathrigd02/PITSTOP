﻿using System; 
using System.Data;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI.WebControls;
using System.Web.Services;
using System.Web.Script.Serialization;
using System.IO;
using System.Text;
using System.Reflection;
using System.Text.RegularExpressions;

namespace karuna.wbsvc
{
    /// <summary>
    /// Summary description for login
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
     [System.Web.Script.Services.ScriptService]
    

        public class login : System.Web.Services.WebService
        {

        [WebMethod(EnableSession = true)]
        public string GetUserId()
        {
            string returnstring = "";

            try
            {
                if (HttpContext.Current.Session["UserId"] != null)
                {
                    returnstring = Convert.ToString(HttpContext.Current.Session["UserId"]);


                }
                else
                {

                }

            }
            catch (Exception ex)
            {
                returnstring = ex.Message;
            }

            return returnstring;
        }



        [WebMethod(EnableSession = true)]

        public string chkLogin(string UserName, string Pswd)
        {
            #region
            string status = string.Empty;

            DataTable dt = CommonClassFile.SelectTable("EXEC Spr_Login '" + UserName + "','" + Pswd + "' ");
            if (dt.Rows.Count > 0)
            {

                status = dt.Rows[0]["Column1"].ToString();
                if (status == "1")
                {


                    DataTable dtemp = CommonClassFile.SelectTable("Select Distinct ID, CusName,Email from Tbl_Customer where Email='" + UserName + "' and Password='" + Pswd + "'   ");
                    if (dtemp.Rows.Count > 0)
                    {
                        HttpContext.Current.Session["UserId"] = dtemp.Rows[0]["ID"].ToString();

                        HttpContext.Current.Session["CusName"] = dtemp.Rows[0]["CusName"].ToString();
                       
                        HttpContext.Current.Session["Email"] = dtemp.Rows[0]["Email"].ToString();



                        

                    }



                }
                else
                {
                    status = "0";
                }


            }

            return status;

            #endregion
        }

        [WebMethod(EnableSession = true)]
            public string GetUserName()
            {
                string UserName = string.Empty;
                try
                {

                    if (HttpContext.Current.Session["Email"] != null)
                    {
                        UserName = HttpContext.Current.Session["Email"].ToString();
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
                finally
                {

                }

                return UserName;
            }

        [WebMethod(EnableSession = true)]
        public string GetCustomer_Name()
        {
            string CusName = string.Empty;
            try
            {

                if (HttpContext.Current.Session["CusName"] != null)
                {
                    CusName = HttpContext.Current.Session["CusName"].ToString();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {

            }

            return CusName;
        }


        [WebMethod(EnableSession = true)]
            public void logout()
            {
                HttpContext.Current.Session.Clear();
                HttpContext.Current.Session.Abandon();
            }

            [WebMethod]
            public string ChangePassword(string op, string np)
            {
                string getop = CommonClassFile.GetSingleValue("Select password from Tbl_Customer where password='" + op + "'");
                string msg = string.Empty;
                if (getop == op)
                {
                    int er = CommonClassFile.InsertOrUpdateorDelete("Update Tbl_Customer SET Password='" + np + "' where Password='" + op + "' ");

                    msg = " New Password has been changed Succssfully...";
                }
                else
                {
                    msg = "Please Enter correct Old Password";
                }

                return msg;
            }


            

        }
     
}
