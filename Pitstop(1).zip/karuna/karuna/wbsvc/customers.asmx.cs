﻿using System;
using System.Data;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI.WebControls;
using System.Web.Services;
using System.Web.Script.Serialization;
using System.IO;
using System.Text;
using System.Reflection;
using System.Text.RegularExpressions;

namespace karuna.wbsvc
{
    /// <summary>
    /// Summary description for customers
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
     [System.Web.Script.Services.ScriptService]
    public class customers : System.Web.Services.WebService
    {
        public class customer
        {
            public string CusName { get; set; }
            public string Custyp { get; set; }
            public string Location { get; set; }
            public string mapurl { get; set; }
            public string map { get; set; }
            public string Address { get; set; }
            public string ContactNo { get; set; }
            public string Email { get; set; }
            public string Password { get; set; }
        }

        [WebMethod]
        public customer[] Get_Mapurl(string location,string category)
        {
            var details = new List<customer>();
            details.Clear();
            details.TrimExcess();
            DataTable dt = new DataTable();
            StringBuilder sb = new StringBuilder();
            try
            {
                if (category == "0")
                {
                    dt = CommonClassFile.SelectTable("Select * from Tbl_Customer where Location='" + location + "'  ");
                }
                else
                {
                    dt = CommonClassFile.SelectTable("Select * from Tbl_Customer where Location='" + location + "' and Customer_type='" + category + "' ");
                }
                

            }
            catch(Exception ex)
            {
                throw ex;
            }
            finally
            {
                foreach(DataRow dr in dt.Rows)
                {
                    customer lst = new customer();
                    lst.CusName = dr["CusName"].ToString();
                    lst.Custyp = dr["Customer_type"].ToString();
                    lst.Location = dr["Location"].ToString();
                    sb.Append("<iframe src='"+ dr["googleMap"].ToString() + "' width='900' height='450' style='border: 0;' allowfullscreen>");
                    sb.Append("</iframe>");
                    lst.mapurl =sb.ToString();
                    lst.Address = dr["Address"].ToString();
                    lst.ContactNo = dr["ContactNo"].ToString();
                    lst.Email = dr["Email"].ToString();
                    details.Add(lst);
                }
            }
            return details.ToArray();
        }

        [WebMethod (EnableSession =true)]
        public customer[] EditRecord(string Email)
        {
            #region
            var details = new List<customer>();
            details.Clear();
            details.TrimExcess();
            DataTable dt = new DataTable();
            StringBuilder sb = new StringBuilder();
            try
            {
                dt = CommonClassFile.SelectTable("Select * from Tbl_Customer where Email='" + Email + "' ");
            }
            catch(Exception ex)
            {
                throw;
            }
            finally
            {
                foreach (DataRow dr in dt.Rows)
                {
                    customer lst = new customer();
                    lst.CusName = dr["CusName"].ToString();
                    if (dr["Customer_type"].ToString()=="Petrol Bunk")
                    {
                        lst.Custyp = "1";
                    }
                    else if (dr["Customer_type"].ToString()=="Mechanics")
                    {
                        lst.Custyp = "2";
                    }
                    else if (dr["Customer_type"].ToString() == "Power")
                    {
                        lst.Custyp = "3";
                    }
                    lst.Location = dr["Location"].ToString();
                    sb.Append("<iframe src='" + dr["googleMap"].ToString() + "' width='920px' height='600px' style='border: 0;' allowfullscreen>");
                    sb.Append("</iframe>");
                    lst.mapurl = sb.ToString();
                    lst.map = dr["googleMap"].ToString();
                    lst.Address = dr["Address"].ToString();
                    lst.ContactNo = dr["ContactNo"].ToString();
                    lst.Email = dr["Email"].ToString();
                    details.Add(lst);
                }
            }
            return details.ToArray();
            #endregion
        }

        [WebMethod]
        public string SaveRecord(customer ph)
        {
            #region
            string msg = string.Empty;
            try
            {

                int res = CommonClassFile.InsertOrUpdateorDelete("Insert into Tbl_Customer (CusName,Email,Password,ContactNo) Values ('" + ph.CusName + "','" + ph.Email + "','"+ph.Password+"','"+ph.ContactNo+"') ");
                msg = "1";
            }
            catch(Exception ex)
            {
                msg ="0";
                throw;

            }
            finally
            {
               
            }

            return msg;
            #endregion
        }

        [WebMethod]
        public string UpdateRecord(customer ph)
        {
            #region
            string msg = string.Empty;
            try
            {

                int res = CommonClassFile.InsertOrUpdateorDelete("Update Tbl_Customer SET CusName='" + ph.CusName + "',ContactNo='" + ph.ContactNo + "',Location='"+ph.Location+"',Address='"+ph.Address+ "',Customer_type='"+ph.Custyp+ "',googleMap='"+ph.mapurl+ "'  where Email='" + ph.Email + "' ");
                msg = "1";
            }
            catch (Exception ex)
            {
                msg = "0";
                throw;

            }
            finally
            {

            }

            return msg;
            #endregion
        }
    }
}
