﻿$(document).ready(function () {

    $('#btnsearch').click(function () {
       
        Get_Map_by_location();

    });

    function Get_Map_by_location()
    {
        var location = $('#txtLocation').val();
        var category = $('#ddlcategory').val();

        $.ajax({
            type: "POST",
            contentType: "application/json; charset=utf-8",
            url: "wbsvc/customers.asmx/Get_Mapurl",
            data: "{location:'" + location + "',category:'" + category + "'}",
            dataType: "json",
            success: function (data) {


                for (var i = 0; i < data.d.length; i++) {
                    $('#lblCustomer').text(data.d[i].CusName);
                    $('#map').html(data.d[i].mapurl);
                    $('#lblAddress').text(data.d[i].Address);
                    $('#lblLocation').text(data.d[i].Location);
                    $('#lblMobNo').text(data.d[i].ContactNo);
                    $('#lblEmail').text(data.d[i].Email);


                }
            },
            error: function (result) {
                alert(result.d);
            }
        });
    }



});