﻿$(document).ready(function () {

    ChkSessionValus();
    $('#btnlogout').click(function () {
        logout();
    });


    
    function GetParameterValues(param) {
        var url = window.location.href.slice(window.location.href.indexOf('?') + 1).split('&');
        for (var i = 0; i < url.length; i++) {
            var urlparam = url[i].split('=');
            if (urlparam[0] == param) {
                return urlparam[1];
            }
        }
    }

    function Get_Map_by_location(mail) {
        var Email = mail;
     

        $.ajax({
            type: "POST",
            contentType: "application/json; charset=utf-8",
            url: "wbsvc/customers.asmx/EditRecord",
            data: "{Email:'" + Email + "'}",
            dataType: "json",
            success: function (data) {


                for (var i = 0; i < data.d.length; i++) {
                    $('#txtCusName').val(data.d[i].CusName);
                    $('#txtMapurl').val(data.d[i].map);
                    $('#map').html(data.d[i].mapurl);
                    $('#txtAddress').text(data.d[i].Address);
                    $('#txtLocation').val(data.d[i].Location);
                    $('#txtMobNo').val(data.d[i].ContactNo);
                    $('#txtEmail').val(data.d[i].Email);
                    $('#ddlCategory').val(data.d[i].Custyp);
                    

                }
            },
            error: function (result) {
                alert(result.d);
            }
        });
    }

    $('#btnUpdate').click(function () {
        UpdateRecord();
    });

    function UpdateRecord()
    {
        var CusName = $('#txtCusName').val();
        var ContactNo = $('#txtMobNo').val();
        var Email = $('#txtEmail').val();
        var Address = $('#txtAddress').val();
        var Location = $('#txtLocation').val();
        var GoogleMapurl = $('#txtMapurl').val();
        var ddlCategory = $('#ddlCategory option:selected').text();


        var user = {};
        user.CusName = CusName;
        user.Custyp = ddlCategory;
        user.Location = Location;
        user.mapurl = GoogleMapurl;
        user.Address = Address;
        user.ContactNo = ContactNo;
        user.Email = Email;

        $.ajax({
            type: "POST",
            url: "wbsvc/customers.asmx/UpdateRecord",
            data: JSON.stringify({ ph: user, }),
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            success: function (data) {

                var result = data.d;

                if (result == "1") {
                    alert('Your Details Updated with us successfullly...')
                    window.location.reload(true);

                }
                else {
                    alert('Error Occured try again later...')
                }




            },
            error: function (response) { alert(response.responseText); }
        });
    }



    function ChkSessionValus() {
        $.ajax({
            type: "POST",
            url: "wbsvc/login.asmx/GetUserName",
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            success: onSuccessGetUserId,
            // error: onError,
            cache: false
        });

        function onSuccessGetUserId(data, status) {

            var ChkUsrName = data.d;

            
            if (ChkUsrName == "") {
                window.location.href = "login.html";


            }
            else {
                $('#txtEmail').val(data.d);
                var mail = data.d;
                Get_Map_by_location(mail);
            }


        }
    }


    function logout() {
        $.ajax({
            type: "POST",
            url: "wbsvc/login.asmx/Logout",
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            success: onSuccessGetUserId,
            // error: onError,
            cache: false
        });

        function onSuccessGetUserId(data, status) {

            window.location = "login.html";

        }
    }

})