﻿

$(document).ready(function () {

    $('#txtUserName').focus();

    $('[id*=btnlogin]').click(function () {
        this.disabeld = true;
        this.innerHTML = "<i style='color:white;font-weight:900;' class='fa fa-spinner fa-spin'></i>";
        var UserName = $('[id*=txtUserName]').val();
        var Password = $('[id*=txtPswd]').val();


        if (UserName == "") {
            document.getElementById('txtUserName').focus();
            document.getElementById('txtUserName').style.borderColor = "red";
            return UserName;

        }
        else {
            document.getElementById('txtUserName').style.borderColor = "#ccc";
        }

        if (Password == "") {
            document.getElementById('txtPswd').focus();
            document.getElementById('txtPswd').style.borderColor = "red";
            return Password;

        }
        else {
            document.getElementById('txtPswd').style.borderColor = "#ccc";
        }

        var Param = '{ "UserName":"' + UserName + '","Pswd":"' + Password + '"   }';


        $.ajax({


            type: "POST",
            url: "wbsvc/login.asmx/chkLogin",
            
            contentType: "application/json; charset=utf-8",
            data: '{"UserName":"' + UserName + '","Pswd":"' + Password + '"}',
            
            dataType: "json",
            success: onSuccessGetUserId,
             
            cache: false
        });

        function onSuccessGetUserId(data, status) {

             
            var ChkUsrName = data.d;

            if (ChkUsrName == "1") {
                window.location = "index.html?Email="+UserName;

              



            }
            else {

                $('[id*=txtUserName]').val('');
                $('[id*=txtPswd]').val('');
                $('#btnlogin').find("i").removeClass("fa fa-spinner fa-spin").addClass("fa fa-search");
                $('#btnlogin').html("<i style='font-weight:900;' class='fa fa-search'></i> Search");
                alert('Invalid UserName or Password ...!!!');
            }

        }




    });

});

$('#txtUserName').change(function () {

    var pswd = $('#txtUserName').val();

    if (pswd != "") {
        $('#txtPswd').focus();
    }
});

$('#txtPswd').change(function () {

    var pswd = $('#txtPswd').val();

    if (pswd != "") {
        $('#btnlogin').focus();
    }
});