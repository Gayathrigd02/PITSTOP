﻿$(document).ready(function () {

    ChkSessionValus();
    Get_userdetails();

     

    $('#btnlogout').click(function () {
        logout();
    });

    (function ($) {
        "use strict"; $('[name="date"]').datepicker({ dateFormat: "dd/mm/yy", showOn: "both", buttonText: '<i class="zmdi zmdi-calendar-alt"></i>', });

    })(jQuery);

    (function ($) {
        "use strict"; $('.dp').datepicker({ dateFormat: "dd/mm/yy", showOn: "both" , });

    })(jQuery);
     

});
 
function converttoindianrupee(amt) {
    var x = amt;
    x = x.toString();
    var afterPoint = '';
    if (x.indexOf('.') > 0)
        afterPoint = x.substring(x.indexOf('.'), x.length);
    x = Math.floor(x);
    x = x.toString();
    var lastThree = x.substring(x.length - 3);
    var otherNumbers = x.substring(0, x.length - 3);
    if (otherNumbers != '')
        lastThree = ',' + lastThree;
    //var res = otherNumbers.replace(/\B(?=(\d{2})+(?!\d))/g, ",") + lastThree + afterPoint;
    var res = otherNumbers.replace(/\B(?=(\d{2})+(?!\d))/g, ",") + lastThree ;

    return res;
}


function GetParameterValues(param) {
    var url = window.location.href.slice(window.location.href.indexOf('?') + 1).split('&');
    for (var i = 0; i < url.length; i++) {
        var urlparam = url[i].split('=');
        if (urlparam[0] == param) {
            return urlparam[1];
        }
    }
}

 


function ChkSessionValus() {
    $.ajax({
        type: "POST",
        url: "wbsvc/login.asmx/GetUserName",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: onSuccessGetUserId,
        // error: onError,
        cache: false
    });

    function onSuccessGetUserId(data, status) {

        var ChkUsrName = data.d;
          
        alert(ChkUsrName);
        if (ChkUsrName == "") {
            window.location.href = "login.html";


        }
        else {
            window.location.href = "index.html"
        }
        

    }
}


function logout() {
    $.ajax({
        type: "POST",
        url: "wbsvc/login.asmx/Logout",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: onSuccessGetUserId,
        // error: onError,
        cache: false
    });

    function onSuccessGetUserId(data, status) {

        window.location = "login.html";

    }
}


function Get_userdetails()
{
    
    //$.ajax({
    //    type: "POST",
    //    contentType: "application/json; charset=utf-8",
    //    url: "wbsvc/login.asmx/GetBranchName",
    //    data: "{}",
    //    dataType: "json",
    //    success: function (data_brnch) {

            
    //        $('#lblbname').text(data_brnch.d);


    //    },
    //    error: function (result_br) {
    //        alert(result_br.d);
    //    }
    //});

    //$.ajax({
    //    type: "POST",
    //    contentType: "application/json; charset=utf-8",
    //    url: "wbsvc/login.asmx/GetCmpName",
    //    data: "{}",
    //    dataType: "json",
    //    success: function (data_cmp) {

           
    //        $('#lblCmpname').text(data_cmp.d);
    //        $('.lblcmpname').text(data_cmp.d);

    //    },
    //    error: function (result_cmo) {
    //        alert(result_cmp.d);
    //    }
    //});

    $.ajax({
        type: "POST",
        contentType: "application/json; charset=utf-8",
        url: "wbsvc/login.asmx/GetUserName",
        data: "{}",
        dataType: "json",
        success: function (data) {

            $('#lblUserName').text(data.d);
            $('#txtEmail').val(data.d);
             
            var spanEle = document.getElementById('txtEmail');
            spanEle.innerText = data.d; //setting text




           

            

        },
        error: function (result_cmpname) {
            alert(result_cmpname.d);
        }
    });

    
}


$('#txtChngpswd').change(function () {

    if (confirm("Are you sure want to change your Password.... ?")) {


        var paswd = $('#txtChngpswd').val();


        $.ajax({
            type: "POST",
            contentType: "application/json; charset=utf-8",
            url: "wbsvc/login.asmx/changepaswd",
            data: "{Pswd:'"+paswd+"'}",
            dataType: "json",
            success: function (data) {

                alert(""+data.d+"");
                logout();
                
               
            },
            error: function (result_cmpname) {
                alert(result_cmpname.d);
            }
        });


       
    }

});


function validate(evt) {
    var theEvent = evt || window.event;

    // Handle paste
    if (theEvent.type === 'paste') {
        key = event.clipboardData.getData('text/plain');
    } else {
        // Handle key press
        var key = theEvent.keyCode || theEvent.which;
        key = String.fromCharCode(key);
    }
    var regex = /[0-9]|\./;
    if (!regex.test(key)) {
        theEvent.returnValue = false;
        if (theEvent.preventDefault) theEvent.preventDefault();
    }
}