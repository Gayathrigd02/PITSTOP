﻿$(document).ready(function () {

    $('#btnRegister').click(function () {
        SaveRecord();
    });

    function SaveRecord()
    {
        var CusName = $('#txtFirstName').val() + '-' + $('#txtLastName').val();
        var MobNo = $('#txtMobNo').val();
        var Email = $('#txtEmail').val();
        var Password = $('#txtPswd').val();
        var ConfirmPassword = $('#txtConfirmPassword').val();
        if(CusName=="-")
        {
            alert('First Name and Last Name is required...!!!');
            $('#txtFirstName').focus();
            return CusName;
        }
        else if(MobNo=="")
        {
            alert('MobileNo is Required...!!!');
            $('#txtMobNo').focus();
            return MobNo;
        }
        else if(Email=="")
        {
            alert('Email is required...!!!');
            $('#txtEmail').focus();
            return Email;
        }
        else if (Password != ConfirmPassword)
        {
            alert('Password is Mis Matching...!!!');
            $('#txtConfirmPassword').focus();
            return ConfirmPassword;
        }
        else if(Password=="")
        {
            alert('Password is Required ...!!!');
            $('#txtPswd').focus();
        }
        else {

            var user = {};
            user.CusName = CusName;
            user.ContactNo = MobNo;
            user.Email = Email;
            user.Password = Password;


            $.ajax({
                type: "POST",
                url: "wbsvc/customers.asmx/SaveRecord",
                data: JSON.stringify({ ph: user, }),
                contentType: "application/json; charset=utf-8",
                dataType: "json",
                success: function (data) {

                    var result = data.d;

                    if (result == "1")
                    {
                        alert('Your Details Registered with us successfullly...')
                        $('#txtFirstName').val('');
                        $('#txtLastName').val('');
                        $('#txtEmail').val('');
                        $('#txtMobNo').val('');
                        $('#txtPswd').val('');
                        $('#txtConfirmPassword').val('');
                        
                    }
                    else {
                        alert('Error Occured try again later...')
                    }
                  
 
                   

                },
                error: function (response) { alert(response.responseText); }
            });
        }

    }
});